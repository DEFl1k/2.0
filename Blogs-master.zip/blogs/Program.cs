﻿using ConsoleApp1.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Linq;
using System.Reflection.Metadata;


var context = new BlogContext();
////////////////////////////////////////////Для вывода
//foreach (Post post in context.Posts) {
//    Console.WriteLine($"=={post.PostName}==");
//    Console.WriteLine(post.Text);
//    Console.WriteLine(post.DatePublication);
//}

////////////////////////////////////////////Для работы с коллекцией
//foreach (Post post in context.Posts.Include(p => p.Blog)) {
//    Console.WriteLine($"{post.Blog.BlogName} - {post.PostName}");
//    Console.WriteLine(post.Text);
//    Console.WriteLine(post.DatePublication);
//}

////////////////////////////////////////////Для работы с одиночной записью
//var post = context.Posts.First();
//context.Entry(post).Reference(p => p.Blog).Load();
//Console.WriteLine($"{post.Blog.BlogName} - {post.PostName}");
//Console.WriteLine(post.Text);
//Console.WriteLine(post.DatePublication);

////////////////////////////////////////////Самостоятельная работа

Console.WriteLine("все посты от самого раннего к самому последнему (упорядочены по дате)");
foreach (Post post in context.Posts.Include(p => p.Blog).OrderBy(p => p.DatePublication))
{
    
    Console.WriteLine($"=={post.PostName}==");
    Console.WriteLine(post.Text);
    Console.WriteLine(post.DatePublication);
    Console.WriteLine("_____________________________");
}

Console.WriteLine();
Console.WriteLine("---------------------------");
Console.WriteLine("все посты одного определенного блога");
foreach (Post post in context.Posts.Include(p => p.Blog).Where(p => p.Blog.BlogName == "Футбольчик с Васькой"))
{
    Console.WriteLine($"=={post.PostName}==");
    Console.WriteLine(post.Text);
    Console.WriteLine(post.DatePublication);
    Console.WriteLine("_____________________________");
}

Console.WriteLine();
Console.WriteLine("---------------------------");
Console.WriteLine("все блоги, имеющие хотя бы одну запись");
foreach (Blog blog in context.Blogs.Include(b => b.Posts).Where(b => b.Posts.Count >= 1))
{
    Console.WriteLine($"=={blog.BlogName}==");
    Console.WriteLine(blog.Autor);
    Console.WriteLine(blog.CreateData);
    Console.WriteLine("_____________________________");
}

Console.WriteLine();
Console.WriteLine("---------------------------");
Console.WriteLine("все блоги, имеющие хотя бы одну запись, написанную не в 2023 году");
DateTime d = Convert.ToDateTime("2023.01.01");
foreach (Post post in context.Posts.Include(p => p.Blog).Where(p => p.DatePublication <= d))
{

    Console.WriteLine($"=={post.Blog.BlogName}==");
    Console.WriteLine(post.Blog.Autor);
    Console.WriteLine(post.Blog.CreateData);
    Console.WriteLine("_____________________________");
}

Console.WriteLine();
Console.WriteLine("---------------------------");
Console.WriteLine("все блоги и количество постов в них");
foreach (Blog blog in context.Blogs.Include(b => b.Posts))
{
    int count = blog.Posts.Count;

    Console.WriteLine($"=={blog.BlogName}==");
    Console.WriteLine(blog.Autor);
    Console.WriteLine(blog.CreateData);
    Console.WriteLine("Число постов в блоге - "+count);
    Console.WriteLine("_____________________________");


}

Console.WriteLine();
Console.WriteLine("---------------------------");
Console.WriteLine("все посты, опубликованные в этом году");
foreach (Post post in context.Posts.Include(p => p.Blog).Where(p => p.DatePublication >= d))
{
    
    Console.WriteLine($"=={post.PostName}==");
    Console.WriteLine(post.Text);
    Console.WriteLine(post.DatePublication);
    Console.WriteLine("_____________________________");

}

Console.WriteLine();
Console.WriteLine("---------------------------");
Console.WriteLine("все посты, сгрупированные по блогам");
foreach (Post post in context.Posts.Include(p => p.Blog).OrderBy(p => p.Blog))
{
    Console.WriteLine($"=={post.Blog.BlogName}==");
    Console.WriteLine($"=={post.PostName}==");
    Console.WriteLine(post.Text);
    Console.WriteLine(post.DatePublication);
    Console.WriteLine("_____________________________");
}







Seeder.InitialSeed();

