﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp1.Models
{
    public class Post
    {
        public int PostId { get; set; }
        public string PostName { get; set; } = string.Empty;
        public string Text { get; set; } = string.Empty;
        public DateTime DatePublication { get; set; }
        public string IsPublished { get; set; } = string.Empty;
        public int BlogId { get; set; }

        public Blog Blog { get; set; }
    }
}
