﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Models {
    public static class Seeder {
        public static void InitialSeed () {
            using (var context = new BlogContext()) {
                if (!context.Blogs.Any()) {


                    //Blog blog = new Blog {
                    //    BlogName = "Кулинария от Макса",
                    //    Autor = "Maks@mail.com",
                    //    CreateData = DateTime.Now.AddDays(-42),
                    //    Posts = new List<Post>()
                    //};
                    //context.Blogs.Add(blog);
                    //blog.Posts.Add(new Post {
                    //    PostName = "О себе",
                    //    Text = "Всем привет, я Макс-повар! В этом блоге я расскажу вам о многих интересных рецептах",
                    //    DatePublication = DateTime.Now.AddDays(-41),
                    //    IsPublished = "true"
                    //});
                    //context.SaveChanges();

                    Blog blog = new Blog {
                        BlogName = "Футбольчик с Васькой",
                        Autor = "Vasya123@mail.com",
                        CreateData = DateTime.Now.AddYears(-3),
                        Posts = new List<Post>()
                    };
                    context.Blogs.Add(blog);
                    blog.Posts.Add(new Post {
                        PostName = "Финты",
                        Text = "Всем привет, я Вася! В этом посте я научу вас делать финты",
                        DatePublication = DateTime.Now.AddYears(-3),
                        IsPublished = "true"
                    });
                    blog.Posts.Add(new Post {
                        PostName = "Правильный удар",
                        Text = "Всем привет, я Вася! В этом посте я научу вас ударять мяч правильно",
                        DatePublication = DateTime.Now.AddMonths(-27),
                        IsPublished = "true"
                    });
                    blog.Posts.Add(new Post {
                        PostName = "Комментаторский матч с Васькой",
                        Text = "Всем привет, я Вася! В этом посте я расскажу, как я комментировал матч",
                        DatePublication = DateTime.Now.AddYears(-2),
                        IsPublished = "false"
                    });
                    


                    Blog blog1 = new Blog {
                        BlogName = "Путешестие с Васькой",
                        Autor = "Vasya321@mail.com",
                        CreateData = DateTime.Now.AddDays(-42),
                        Posts = new List<Post>()
                    };
                    context.Blogs.Add(blog1);
                    
                    



                    Blog blog2 = new Blog {
                        BlogName = "Рисоване с Максимом",
                        Autor = "Makson322@mail.com",
                        CreateData = DateTime.Now.AddMonths(-8),
                        Posts = new List<Post>()
                    };
                    context.Blogs.Add(blog2);
                    blog2.Posts.Add(new Post {
                        PostName = "База",
                        Text = "Всем привет, я Максим! В этом посте я научу вас основе рсования",
                        DatePublication = DateTime.Now.AddMonths(-4),
                        IsPublished = "true"
                    });
                    blog2.Posts.Add(new Post {
                        PostName = "Продвинутое рисование",
                        Text = "Всем привет, я Максим! В этом посте я научу вас рисовать на продвинутом уровне",
                        DatePublication = DateTime.Now.AddMonths(-2),
                        IsPublished = "true"
                    });
                    context.SaveChanges();
                }
            }
        }
    }
}
